import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'birthayfilt'
})
export class BirthayfiltPipe implements PipeTransform {

  transform(workers,sorting,) {

    
  }

}
