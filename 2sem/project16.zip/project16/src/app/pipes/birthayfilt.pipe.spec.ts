import { BirthayfiltPipe } from './birthayfilt.pipe';

describe('BirthayfiltPipe', () => {
  it('create an instance', () => {
    const pipe = new BirthayfiltPipe();
    expect(pipe).toBeTruthy();
  });
});
