import { IdfiltPipe } from './idfilt.pipe';

describe('IdfiltPipe', () => {
  it('create an instance', () => {
    const pipe = new IdfiltPipe();
    expect(pipe).toBeTruthy();
  });
});
