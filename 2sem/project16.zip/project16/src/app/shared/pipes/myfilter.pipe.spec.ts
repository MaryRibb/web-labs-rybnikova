import { MyfilterPipe } from './myfilter.pipe';

describe('MyfilterPipe', () => {
  it('create an instance', () => {
    const pipe = new MyfilterPipe();
    expect(pipe).toBeTruthy();
  });
});
